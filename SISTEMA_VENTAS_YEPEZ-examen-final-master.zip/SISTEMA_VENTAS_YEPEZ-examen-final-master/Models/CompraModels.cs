﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace DEC3MI_STORE.Models
{
    public class CompraModels
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Campo obligatorio")]
        [Display(Name = "Fecha de compra")]
        public DateTime Fecha { get; set; }

        [Required(ErrorMessage = "Campo obligatorio")]
        public int ProveedorId { get; set; }
        public ProveedorModels Proveedor { get; set; }

        [Required(ErrorMessage = "Campo obligatorio")]
        [Column(TypeName = "decimal(18,2)")]
        [Display(Name = "Monto total de la compra")]
        public decimal MontoTotal { get; set; }

        public List<CompraDetalleModels> DetallesCompra { get; set; } = new List<CompraDetalleModels>();

    }
}
