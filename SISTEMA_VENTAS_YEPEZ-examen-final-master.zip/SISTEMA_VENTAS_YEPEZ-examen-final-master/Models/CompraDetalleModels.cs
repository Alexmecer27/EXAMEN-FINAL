﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace DEC3MI_STORE.Models
{
    public class CompraDetalleModels
    {
        public int Id { get; set; }

        [Required]
        public int CompraId { get; set; }
        public CompraModels Compra { get; set; }

        [Required]
        public int ProductoId { get; set; }
        public ProductoModels Producto { get; set; }

        [Required(ErrorMessage = "Campo obligatorio")]
        [Display(Name = "Cantidad comprada")]
        public int Cantidad { get; set; }

        [Required(ErrorMessage = "Campo obligatorio")]
        [Column(TypeName = "decimal(18,2)")]
        [Display(Name = "Precio unitario de compra")]
        public decimal PrecioUnitario { get; set; }
    }
}
