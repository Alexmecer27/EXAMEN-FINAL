﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using DEC3MI_STORE.Config;
using DEC3MI_STORE.Models;

namespace SISTEMA_VENTAS_YEPEZ.Controllers
{
    public class CompraModelsController : Controller
    {
        private readonly StoreAppContext _context;

        public CompraModelsController(StoreAppContext context)
        {
            _context = context;
        }

        // GET: CompraModels
        public async Task<IActionResult> Index()
        {
            var storeAppContext = _context.Compras.Include(c => c.Proveedor);
            return View(await storeAppContext.ToListAsync());
        }

        // GET: CompraModels/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var compraModels = await _context.Compras
                .Include(c => c.Proveedor)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (compraModels == null)
            {
                return NotFound();
            }

            return View(compraModels);
        }

        // GET: CompraModels/Create
        public IActionResult Create()
        {
            ViewData["ProveedorId"] = new SelectList(_context.Proveedores, "Id", "Direccion");
            return View();
        }

        // POST: CompraModels/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Fecha,ProveedorId,MontoTotal")] CompraModels compraModels)
        {
            if (ModelState.IsValid)
            {
                _context.Add(compraModels);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["ProveedorId"] = new SelectList(_context.Proveedores, "Id", "Direccion", compraModels.ProveedorId);
            return View(compraModels);
        }

        // GET: CompraModels/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var compraModels = await _context.Compras.FindAsync(id);
            if (compraModels == null)
            {
                return NotFound();
            }
            ViewData["ProveedorId"] = new SelectList(_context.Proveedores, "Id", "Direccion", compraModels.ProveedorId);
            return View(compraModels);
        }

        // POST: CompraModels/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Fecha,ProveedorId,MontoTotal")] CompraModels compraModels)
        {
            if (id != compraModels.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(compraModels);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CompraModelsExists(compraModels.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["ProveedorId"] = new SelectList(_context.Proveedores, "Id", "Direccion", compraModels.ProveedorId);
            return View(compraModels);
        }

        // GET: CompraModels/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var compraModels = await _context.Compras
                .Include(c => c.Proveedor)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (compraModels == null)
            {
                return NotFound();
            }

            return View(compraModels);
        }

        // POST: CompraModels/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var compraModels = await _context.Compras.FindAsync(id);
            if (compraModels != null)
            {
                _context.Compras.Remove(compraModels);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CompraModelsExists(int id)
        {
            return _context.Compras.Any(e => e.Id == id);
        }
    }
}
