﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace DEC3MI_STORE.Models
{
    public class VentaModels
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Campo obligatorio")]
        [Display(Name = "Fecha de la venta")]
        public DateTime Fecha { get; set; }

        [Required(ErrorMessage = "Campo obligatorio")]
        [Display(Name = "Nombre del cliente")]
        public string Cliente { get; set; }

        [Required(ErrorMessage = "Campo obligatorio")]
        [Column(TypeName = "decimal(18,2)")]
        [Display(Name = "Total de la venta")]
        public decimal TotalVenta { get; set; }

        public List<VentaDetalleModels> DetallesVenta { get; set; } = new List<VentaDetalleModels>();

    }
}
