﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using DEC3MI_STORE.Config;
using DEC3MI_STORE.Models;

namespace SISTEMA_VENTAS_YEPEZ.Controllers
{
    public class ProductoModelsController : Controller
    {
        private readonly StoreAppContext _context;

        public ProductoModelsController(StoreAppContext context)
        {
            _context = context;
        }

        // GET: ProductoModels
        public async Task<IActionResult> Index()
        {
            var storeAppContext = _context.Productos.Include(p => p.Proveedor);
            return View(await storeAppContext.ToListAsync());
        }

        // GET: ProductoModels/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var productoModels = await _context.Productos
                .Include(p => p.Proveedor)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (productoModels == null)
            {
                return NotFound();
            }

            return View(productoModels);
        }

        // GET: ProductoModels/Create
        public IActionResult Create()
        {
            ViewData["ProveedorId"] = new SelectList(_context.Proveedores, "Id", "Direccion");
            return View();
        }

        // POST: ProductoModels/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Nombre,PrecioCompra,PrecioVenta,Stock,ProveedorId")] ProductoModels productoModels)
        {
            if (ModelState.IsValid)
            {
                _context.Add(productoModels);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["ProveedorId"] = new SelectList(_context.Proveedores, "Id", "Direccion", productoModels.ProveedorId);
            return View(productoModels);
        }

        // GET: ProductoModels/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var productoModels = await _context.Productos.FindAsync(id);
            if (productoModels == null)
            {
                return NotFound();
            }
            ViewData["ProveedorId"] = new SelectList(_context.Proveedores, "Id", "Direccion", productoModels.ProveedorId);
            return View(productoModels);
        }

        // POST: ProductoModels/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Nombre,PrecioCompra,PrecioVenta,Stock,ProveedorId")] ProductoModels productoModels)
        {
            if (id != productoModels.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(productoModels);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ProductoModelsExists(productoModels.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["ProveedorId"] = new SelectList(_context.Proveedores, "Id", "Direccion", productoModels.ProveedorId);
            return View(productoModels);
        }

        // GET: ProductoModels/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var productoModels = await _context.Productos
                .Include(p => p.Proveedor)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (productoModels == null)
            {
                return NotFound();
            }

            return View(productoModels);
        }

        // POST: ProductoModels/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var productoModels = await _context.Productos.FindAsync(id);
            if (productoModels != null)
            {
                _context.Productos.Remove(productoModels);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ProductoModelsExists(int id)
        {
            return _context.Productos.Any(e => e.Id == id);
        }
    }
}
