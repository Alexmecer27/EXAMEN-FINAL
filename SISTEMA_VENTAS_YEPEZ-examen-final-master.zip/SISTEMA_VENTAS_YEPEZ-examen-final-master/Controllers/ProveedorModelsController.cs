﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using DEC3MI_STORE.Config;
using DEC3MI_STORE.Models;

namespace SISTEMA_VENTAS_YEPEZ.Controllers
{
    public class ProveedorModelsController : Controller
    {
        private readonly StoreAppContext _context;

        public ProveedorModelsController(StoreAppContext context)
        {
            _context = context;
        }

        // GET: ProveedorModels
        public async Task<IActionResult> Index()
        {
            return View(await _context.Proveedores.ToListAsync());
        }

        // GET: ProveedorModels/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var proveedorModels = await _context.Proveedores
                .FirstOrDefaultAsync(m => m.Id == id);
            if (proveedorModels == null)
            {
                return NotFound();
            }

            return View(proveedorModels);
        }

        // GET: ProveedorModels/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: ProveedorModels/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,RUC,Nombre,Direccion,Telefono,PaginaWeb")] ProveedorModels proveedorModels)
        {
            if (ModelState.IsValid)
            {
                _context.Add(proveedorModels);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(proveedorModels);
        }

        // GET: ProveedorModels/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var proveedorModels = await _context.Proveedores.FindAsync(id);
            if (proveedorModels == null)
            {
                return NotFound();
            }
            return View(proveedorModels);
        }

        // POST: ProveedorModels/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,RUC,Nombre,Direccion,Telefono,PaginaWeb")] ProveedorModels proveedorModels)
        {
            if (id != proveedorModels.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(proveedorModels);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ProveedorModelsExists(proveedorModels.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(proveedorModels);
        }

        // GET: ProveedorModels/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var proveedorModels = await _context.Proveedores
                .FirstOrDefaultAsync(m => m.Id == id);
            if (proveedorModels == null)
            {
                return NotFound();
            }

            return View(proveedorModels);
        }

        // POST: ProveedorModels/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var proveedorModels = await _context.Proveedores.FindAsync(id);
            if (proveedorModels != null)
            {
                _context.Proveedores.Remove(proveedorModels);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ProveedorModelsExists(int id)
        {
            return _context.Proveedores.Any(e => e.Id == id);
        }
    }
}
