﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using DEC3MI_STORE.Config;
using DEC3MI_STORE.Models;

namespace SISTEMA_VENTAS_YEPEZ.Controllers
{
    public class TelefonoClientesController : Controller
    {
        private readonly StoreAppContext _context;

        public TelefonoClientesController(StoreAppContext context)
        {
            _context = context;
        }

        // GET: TelefonoClientes
        public async Task<IActionResult> Index()
        {
            var storeAppContext = _context.TelefonoCliente.Include(t => t.Cliente);
            return View(await storeAppContext.ToListAsync());
        }

        // GET: TelefonoClientes/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var telefonoCliente = await _context.TelefonoCliente
                .Include(t => t.Cliente)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (telefonoCliente == null)
            {
                return NotFound();
            }

            return View(telefonoCliente);
        }

        // GET: TelefonoClientes/Create
        public IActionResult Create()
        {
            ViewData["ClienteId"] = new SelectList(_context.Clientes, "Id", "CedulaORUC");
            return View();
        }

        // POST: TelefonoClientes/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Numero,ClienteId")] TelefonoCliente telefonoCliente)
        {
            if (ModelState.IsValid)
            {
                _context.Add(telefonoCliente);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["ClienteId"] = new SelectList(_context.Clientes, "Id", "CedulaORUC", telefonoCliente.ClienteId);
            return View(telefonoCliente);
        }

        // GET: TelefonoClientes/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var telefonoCliente = await _context.TelefonoCliente.FindAsync(id);
            if (telefonoCliente == null)
            {
                return NotFound();
            }
            ViewData["ClienteId"] = new SelectList(_context.Clientes, "Id", "CedulaORUC", telefonoCliente.ClienteId);
            return View(telefonoCliente);
        }

        // POST: TelefonoClientes/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Numero,ClienteId")] TelefonoCliente telefonoCliente)
        {
            if (id != telefonoCliente.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(telefonoCliente);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TelefonoClienteExists(telefonoCliente.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["ClienteId"] = new SelectList(_context.Clientes, "Id", "CedulaORUC", telefonoCliente.ClienteId);
            return View(telefonoCliente);
        }

        // GET: TelefonoClientes/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var telefonoCliente = await _context.TelefonoCliente
                .Include(t => t.Cliente)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (telefonoCliente == null)
            {
                return NotFound();
            }

            return View(telefonoCliente);
        }

        // POST: TelefonoClientes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var telefonoCliente = await _context.TelefonoCliente.FindAsync(id);
            if (telefonoCliente != null)
            {
                _context.TelefonoCliente.Remove(telefonoCliente);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TelefonoClienteExists(int id)
        {
            return _context.TelefonoCliente.Any(e => e.Id == id);
        }
    }
}
