﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace DEC3MI_STORE.Models
{
    public class ProductoModels
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Campo obligatorio")]
        [Display(Name = "Nombre del producto")]
        public string Nombre { get; set; }

        [Required(ErrorMessage = "Campo obligatorio")]
        [Column(TypeName = "decimal(18,2)")]
        [Display(Name = "Precio de compra")]
        public decimal PrecioCompra { get; set; }

        [Required(ErrorMessage = "Campo obligatorio")]
        [Column(TypeName = "decimal(18,2)")]
        [Display(Name = "Precio de venta")]
        public decimal PrecioVenta { get; set; }

        [Required(ErrorMessage = "Campo obligatorio")]
        [Display(Name = "Cantidad en stock")]
        public int Stock { get; set; }

        public int ProveedorId { get; set; }
        public ProveedorModels Proveedor { get; set; }
    }
}
