﻿using DEC3MI_STORE.Models;
using Microsoft.EntityFrameworkCore;

namespace DEC3MI_STORE.Config
    
{
    public class StoreAppContext: DbContext
    {
    public StoreAppContext(DbContextOptions contexto) : base(contexto)
    {
        
    }
        public DbSet<Cliente> Clientes { get; set; }

        public DbSet<ProveedorModels> Proveedores { get; set; }
        public DbSet<ProductoModels> Productos { get; set; }
        public DbSet<CompraModels> Compras { get; set; }
        public DbSet<CompraDetalleModels> DetallesCompras { get; set; }
        public DbSet<VentaModels> Ventas { get; set; }
        public DbSet<VentaDetalleModels> DetallesVentas { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
           modelBuilder.Entity<ProductoModels>()
                .HasOne(p => p.Proveedor)
                .WithMany(prov => prov.Productos)
                .HasForeignKey(p => p.ProveedorId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<CompraModels>()
                .HasOne(c => c.Proveedor)
                .WithMany()
                .HasForeignKey(c => c.ProveedorId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<CompraDetalleModels>()
                .HasOne(cd => cd.Compra)
                .WithMany(c => c.DetallesCompra)
                .HasForeignKey(cd => cd.CompraId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<CompraDetalleModels>()
                .HasOne(cd => cd.Producto)
                .WithMany()
                .HasForeignKey(cd => cd.ProductoId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<VentaDetalleModels>()
                .HasOne(vd => vd.Venta)
                .WithMany(v => v.DetallesVenta)
                .HasForeignKey(vd => vd.VentaId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<VentaDetalleModels>()
                .HasOne(vd => vd.Producto)
                .WithMany()
                .HasForeignKey(vd => vd.ProductoId)
                .OnDelete(DeleteBehavior.Restrict);
        }
        public DbSet<DEC3MI_STORE.Models.TelefonoCliente> TelefonoCliente { get; set; } = default!;

    }
}
