﻿using System.ComponentModel.DataAnnotations;

namespace DEC3MI_STORE.Models
{
    public class Cliente
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Campo obligatorio")]
        [Display(Name = "Cédula o RUC")]
        public string CedulaORUC { get; set; }

        [Required(ErrorMessage = "Campo obligatorio")]
        [Display(Name = "Nombre del cliente")]
        public string Nombre { get; set; }

        [Display(Name = "Dirección")]
        public string Direccion { get; set; }

        [Display(Name = "Correo Electrónico")]
        [EmailAddress(ErrorMessage = "Correo electrónico no válido")]
        public string CorreoElectronico { get; set; }

        public ICollection<TelefonoCliente> Telefonos { get; set; } = new List<TelefonoCliente>();
    }
    public class TelefonoCliente
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Campo obligatorio")]
        [Display(Name = "Número de Teléfono")]
        public string Numero { get; set; }

        public int ClienteId { get; set; }
        public Cliente Cliente { get; set; }
    }
}
