﻿using System.ComponentModel.DataAnnotations;

namespace DEC3MI_STORE.Models
{
    public class ProveedorModels
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Campo obligatorio")]
        [Display(Name = "RUC del proveedor")]
        public string RUC { get; set; }

        [Required(ErrorMessage = "Campo obligatorio")]
        [Display(Name = "Nombre del proveedor")]
        public string Nombre { get; set; }

        [Required(ErrorMessage = "Campo obligatorio")]
        [Display(Name = "Dirección de la empresa")]
        public string Direccion { get; set; }

        [Required(ErrorMessage = "Campo obligatorio")]
        [Display(Name = "Teléfono")]
        public string Telefono { get; set; }

        [Required(ErrorMessage = "Campo obligatorio")]
        [Display(Name = "Página web")]
        public string PaginaWeb { get; set; }

        public List<ProductoModels> Productos { get; set; } = new List<ProductoModels>();

    }
}
