﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using DEC3MI_STORE.Config;
using DEC3MI_STORE.Models;

namespace SISTEMA_VENTAS_YEPEZ.Controllers
{
    public class CompraDetalleModelsController : Controller
    {
        private readonly StoreAppContext _context;

        public CompraDetalleModelsController(StoreAppContext context)
        {
            _context = context;
        }

        // GET: CompraDetalleModels
        public async Task<IActionResult> Index()
        {
            var storeAppContext = _context.DetallesCompras.Include(c => c.Compra).Include(c => c.Producto);
            return View(await storeAppContext.ToListAsync());
        }

        // GET: CompraDetalleModels/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var compraDetalleModels = await _context.DetallesCompras
                .Include(c => c.Compra)
                .Include(c => c.Producto)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (compraDetalleModels == null)
            {
                return NotFound();
            }

            return View(compraDetalleModels);
        }

        // GET: CompraDetalleModels/Create
        public IActionResult Create()
        {
            ViewData["CompraId"] = new SelectList(_context.Compras, "Id", "Id");
            ViewData["ProductoId"] = new SelectList(_context.Productos, "Id", "Nombre");
            return View();
        }

        // POST: CompraDetalleModels/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,CompraId,ProductoId,Cantidad,PrecioUnitario")] CompraDetalleModels compraDetalleModels)
        {
            if (ModelState.IsValid)
            {
                _context.Add(compraDetalleModels);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["CompraId"] = new SelectList(_context.Compras, "Id", "Id", compraDetalleModels.CompraId);
            ViewData["ProductoId"] = new SelectList(_context.Productos, "Id", "Nombre", compraDetalleModels.ProductoId);
            return View(compraDetalleModels);
        }

        // GET: CompraDetalleModels/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var compraDetalleModels = await _context.DetallesCompras.FindAsync(id);
            if (compraDetalleModels == null)
            {
                return NotFound();
            }
            ViewData["CompraId"] = new SelectList(_context.Compras, "Id", "Id", compraDetalleModels.CompraId);
            ViewData["ProductoId"] = new SelectList(_context.Productos, "Id", "Nombre", compraDetalleModels.ProductoId);
            return View(compraDetalleModels);
        }

        // POST: CompraDetalleModels/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,CompraId,ProductoId,Cantidad,PrecioUnitario")] CompraDetalleModels compraDetalleModels)
        {
            if (id != compraDetalleModels.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(compraDetalleModels);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CompraDetalleModelsExists(compraDetalleModels.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["CompraId"] = new SelectList(_context.Compras, "Id", "Id", compraDetalleModels.CompraId);
            ViewData["ProductoId"] = new SelectList(_context.Productos, "Id", "Nombre", compraDetalleModels.ProductoId);
            return View(compraDetalleModels);
        }

        // GET: CompraDetalleModels/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var compraDetalleModels = await _context.DetallesCompras
                .Include(c => c.Compra)
                .Include(c => c.Producto)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (compraDetalleModels == null)
            {
                return NotFound();
            }

            return View(compraDetalleModels);
        }

        // POST: CompraDetalleModels/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var compraDetalleModels = await _context.DetallesCompras.FindAsync(id);
            if (compraDetalleModels != null)
            {
                _context.DetallesCompras.Remove(compraDetalleModels);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CompraDetalleModelsExists(int id)
        {
            return _context.DetallesCompras.Any(e => e.Id == id);
        }
    }
}
