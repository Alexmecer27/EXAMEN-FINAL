﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace DEC3MI_STORE.Models
{
    public class VentaDetalleModels
    {
        public int Id { get; set; }

        [Required]
        public int VentaId { get; set; }
        public VentaModels Venta { get; set; }

        [Required]
        public int ProductoId { get; set; }
        public ProductoModels Producto { get; set; }

        [Required(ErrorMessage = "Campo obligatorio")]
        [Display(Name = "Cantidad vendida")]
        public int Cantidad { get; set; }

        [Required(ErrorMessage = "Campo obligatorio")]
        [Column(TypeName = "decimal(18,2)")]
        [Display(Name = "Precio de venta en ese momento")]
        public decimal PrecioUnitario { get; set; }
    }
}
